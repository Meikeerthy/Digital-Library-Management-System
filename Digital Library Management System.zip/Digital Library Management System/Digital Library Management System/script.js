$(document).ready(function(){
    $("#exploreBtn").click(function(){
        alert("Feature coming soon!");
    });
});
